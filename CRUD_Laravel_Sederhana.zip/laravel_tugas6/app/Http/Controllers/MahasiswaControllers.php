<?php

namespace App\Http\Controllers;

use App\Models\Mahasiswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class MahasiswaControllers extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $mahasisw = Mahasiswa::latest()->paginate(5);
        return view('mahasisw.index', compact('mahasisw'))->with('i', (request()->input('page', 1) -1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('mahasisw.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'NIM'=>'required',
            'NamaMahasiswa'=>'required',
        ]);
        Mahasiswa::create($request->all());

        return redirect()->route('mahasisw.index')->with('succes', 'Data Berhasil di Input');
    }

    /**
     * Display the specified resource.
     */
    public function show(Mahasiswa $mahasisw)
    {
        return view('mahasisw.show', compact('mahasisw'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Mahasiswa $mahasisw)
    {
        return view('mahasisw.edit', compact('mahasisw'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Mahasiswa $mahasisw)
    {
        $request->validate([
            'NIM'=>'required',
            'NamaMahasiswa'=>'required',
        ]);

        $mahasisw->update($request->all());
        return redirect()->route('mahasisw.index')->with('succes', 'Mahasiswa Berhasil di Update');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Mahasiswa $mahasisw)
    {
        $mahasisw->delete();
        return redirect()->route('mahasisw.index')->with('succes', 'Mahasiswa Berhasil di Hapus');
    }
}
